# ========COMPASS===========

import cv2 #menimport package cv2
import matplotlib.pyplot as plt #mengimport matplotlib.pyplot as plt

img = cv2.imread('rusa.png') #membaca img (rusa.png)
edges = cv2.Canny(img,25,255,L2gradient=False) # img : nama gambar, 25 : lower threshold, 255 : upper threshold.
# kemudian L2GRADIENT = false

plt.subplot(121),plt.imshow(img,cmap = 'gray') #memperlihatkan img dan diletakan di posisi (121)
# serta keabu-abuan
plt.title('Original Image'), plt.xticks([]), plt.yticks([]) #penempatan pada axis x dan y
plt.subplot(122),plt.imshow(edges,cmap = 'gray') #memperlihatkan edge dan diletakan di posisi (122)
# serta keabu-abuan
plt.title('Edges'), plt.xticks([]), plt.yticks([]) #penempatan pada axis x dan y
plt.show() #display image

#============CANNY=================

import cv2  #mengimport package cv2 untuk image processing
import matplotlib.pyplot as plt  #mengimport package matplotlib

im = cv2.imread('Burgerr.png') #memasukan image yang bernama Burgerr.png
edges = cv2.Canny(im,25,255,L2gradient=False)  # im : nama gambar, 25 : lower threshold, 255 : upper threshold. kemudian L2GRADIENT = false

plt.imshow(edges,cmap='gray') #function untuk memperlihatkan edges dengan warna gray (abu2)
plt.show() #prosedur untuk menampilkan gambar yang sudah diproses


#===============SOBEL================

import numpy as np  # mengimport package numpy
import cv2  # mengimport cv2
from matplotlib import pyplot as plt  # mengimport package matplotlib


def sobelOperator(img):  # membuat function dan parameternya bernama img
    container = np.copy(img)  # mengcopy img ke dalam variabel container
    size = container.shape  # menginputkan variabel container ke dalam variabel size


for i in range(1, size[0] - 1):  #
    for j in range(1, size[1] - 1):
        # melakukan perhitungan terhadap sumbu x, dimana nilai tersebut dimasukan ke dalam variabel gx
        gx = (img[i - 1][j - 1] + 2 * img[i][j - 1] + img[i + 1][j - 1]) - (
                    img[i - 1][j + 1] + 2 * img[i][j + 1] + img[i + 1][j + 1])


gy = (img[i - 1][j - 1] + 2 * img[i - 1][j] + img[i - 1][j + 1]) - (
            img[i + 1][j - 1] + 2 * img[i + 1][j] + img[i + 1][j + 1])
container[i][j] = min(255, np.sqrt(gx ** 2 + gy ** 2))

# melakukan perhitungan, dan dimasukan ke dalam variabel container

return container  # mengembalikan nilai container
pass

img = cv2.cvtColor(cv2.imread("Burgerr.png"), cv2.COLOR_BGR2GRAY)  # cv2.cvtColor : method untuk mengubah warna gambar,
# cv2.imread "Burgerr.png" :membaca gambar bernama Burgerr.png, cv2.COLOR_BGR2GRAY : method untuk mengubah warna gambar menjadi abu2
img = sobelOperator(
    img)  # menjalankan method sobelOperator pada parameter img, dan kemudian dimasukan dalam variabel img
img = cv2.cvtColor(img,
                   cv2.COLOR_GRAY2RGB)  # memsaukan nilai img setelah sobelOperator, dan menampilkannya dalam warna abu2
plt.imshow(img)  # membuat image 2 dimensi dari numpy array
plt.show()  # membuat display dari img



#==============EMBOSS==============

from PIL import Image  # package PIL untuk import image

from PIL import ImageFilter  # package PIL untuk image filter

# Open the Image and create an Image Object

imagePath = "./StatueOfLiberty.jpg"  # membuka dan membuat image object dan masuk dalam variabel imagePath

imageObject = Image.open(imagePath)  # membuka image dalam variabel imagePath

imageObject.show()  # display image (sebelum di filter) dalam variabel imagePath

imageEmboss = imageObject.filter(ImageFilter.EMBOSS)  # memfilter image dengan method embhoss

imageEmboss.show()  # display image yang sudah di emboss




#================IMAGE GRADIEN===============

import numpy as np  #import package numpy as np
import cv2 as cv  #import package cv2 as cv
from matplotlib import pyplot as plt  # dari matplotlib import pyplot as plt

img = cv.imread('liberty.jpg',0) #membaca liberty.jpg dan ditampung variabel img
laplacian = cv.Laplacian(img,cv.CV_64F)  #melakukan gradien laplacian pada img
sobelx = cv.Sobel(img,cv.CV_64F,1,0,ksize=5) #melakukan gradien sobel secara horizontal pada img dg ksize=5

sobely = cv.Sobel(img,cv.CV_64F,0,1,ksize=5)  #melakukan gradien sobel secara vertikal pada img dg ksize=5

plt.subplot(2,2,1),plt.imshow(img,cmap = 'gray') #meletakan di posisi (2,2,1) pada window kemudian display img warna abu2
plt.title('Original'), plt.xticks([]), plt.yticks([]) #memberikan title Original

plt.subplot(2,2,2),plt.imshow(laplacian,cmap = 'gray') #meletakan di posisi (2,2,2) pada window kemudian display laplacian  warna abu2
plt.title('Laplacian'), plt.xticks([]), plt.yticks([]) #memberikan title Laplacian

plt.subplot(2,2,3),plt.imshow(sobelx,cmap = 'gray') #meletakan di posisi (2,2,3) pada window kemudian display sobelx warna abu2
plt.title('Sobel X'), plt.xticks([]), plt.yticks([]) #memberikan title Sobel X

plt.subplot(2,2,4),plt.imshow(sobely,cmap = 'gray') #meletakan di posisi (2,2,4) pada window kemudian display sobely warna abu2
plt.title('Sobel Y'), plt.xticks([]), plt.yticks([])  #memberikan title Sobel Y

plt.show() #display image


#================PREWITT==================

import cv2 # import packager cv2
import numpy as np iport package numpy sebagai np

img = cv2.imread('Burgerr.jpg') #cv2 membaca gambar (Burgerr.jpg) dan masuk dalam variabel img
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) # variabel gray dengan nilainya adalah mengubah img menjadi abu2
img_gaussian = cv2.GaussianBlur(gray,(3,3),0) #melakukan method cv2.GaussianBlur pada gray

#prewitt
kernelx = np.array([[1,1,1],[0,0,0],[-1,-1,-1]])
kernely = np.array([[-1,0,1],[-1,0,1],[-1,0,1]])
img_prewittx = cv2.filter2D(img_gaussian, -1, kernelx)
img_prewitty = cv2.filter2D(img_gaussian, -1, kernely)


cv2.imshow("Original Image", img) #memperlihatkan img sebagai original image
cv2.imshow("Prewitt X", img_prewittx)#memperlihatkan img_prewittx sebagai  Prewitt X

cv2.imshow("Prewitt Y", img_prewitty) #memperlihatkan sebagai img_prewitty  Prewitt Y

cv2.imshow("Prewitt", img_prewittx + img_prewitty) memperlihatkan img_prewitty+img_prewittX sebagai   Prewitt


cv2.waitKey(0)
cv2.destroyAllWindows()


#================KIRSCH======================

import numpy as np #import numpy sebagai np

import cv2 #import cv2
def kirsch_filter(gray): #membuat suatu fungsi yaitu kirsch_filter dg parameter (gray)
#kondisional terhadap gray
    if gray.ndim > 2:
        raise Exception("illegal argument: input must be a single channel image (gray)")

    kernelG1 = np.array([[ 5,  5,  5],
                         [-3,  0, -3],
                         [-3, -3, -3]], dtype=np.float32)
    kernelG2 = np.array([[ 5,  5, -3],
                         [ 5,  0, -3],
                         [-3, -3, -3]], dtype=np.float32)
    kernelG3 = np.array([[ 5, -3, -3],
                         [ 5,  0, -3],
                         [ 5, -3, -3]], dtype=np.float32)
    kernelG4 = np.array([[-3, -3, -3],
                         [ 5,  0, -3],
                         [ 5,  5, -3]], dtype=np.float32)
    kernelG5 = np.array([[-3, -3, -3],
                         [-3,  0, -3],
                         [ 5,  5,  5]], dtype=np.float32)
    kernelG6 = np.array([[-3, -3, -3],
                         [-3,  0,  5],
                         [-3,  5,  5]], dtype=np.float32)
    kernelG7 = np.array([[-3, -3,  5],
                         [-3,  0,  5],
                         [-3, -3,  5]], dtype=np.float32)
    kernelG8 = np.array([[-3,  5,  5],
                         [-3,  0,  5],
                         [-3, -3, -3]], dtype=np.float32)


    g1 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG1), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g2 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG2), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g3 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG3), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g4 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG4), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g5 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG5), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g6 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG6), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g7 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG7), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    g8 = cv2.normalize(cv2.filter2D(gray, cv2.CV_32F, kernelG8), None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8UC1)
    magn = cv2.max(
        g1, cv2.max(
            g2, cv2.max(
                g3, cv2.max(
                    g4, cv2.max(
                        g5, cv2.max(
                            g6, cv2.max(
                                g7, g8
                            )
                        )
                    )
                )
            )
        )
    )
return magn

#display image
fg = cv2.imread("liberty.png")
fg_rgb = cv2.cvtColor(fg, cv2.COLOR_BGR2RGB)
gray = cv2.cvtColor(fg_rgb, cv2.COLOR_RGB2GRAY)
bin = kirsch_filter(gray)# show results
plt.imshow(bin, interpolation='none', cmap='gray')
plt.xticks([]), plt.yticks([])
plt.show()


#==============GAUSSIAN===================

import cv2  #import package cv2
import numpy as np #import package numpy sebagai np
from matplotlib import pyplot as plt

img = cv2.imread('opencv_logo.png') #membaca gambar ('rusa.png') dan memasukannya dalam variabel img

#Gaussian Blur
kernel = np.ones((5,5),np.float32)/25
dst = cv2.filter2D(img,-1,kernel)
blur = cv2.GaussianBlur(dst,(5,5),0)

plt.subplot(121),plt.imshow(img),plt.title('Original') #menempatkan img pada posisi (121) dan memberikan title ('Original')
plt.xticks([]), plt.yticks([]) #menempatkan x dan y axis
plt.subplot(122),plt.imshow(blur),plt.title('Gaussian') #menempatkan blur pada posisi (121) dan memberikan title ('Gaussian')
plt.xticks([]), plt.yticks([]) #menempatkan x dan y axis

plt.show() #display image

#======================LOG=======================

import cv2  # import cv2
import numpy as np  # import numpy sebagai np
import matplotlib.pyplot as plt  # import matplotlib.pyplot sebagai plt

image = cv2.imread('rusa.jpg')  # membaca image

# melakukan method log transformation
c = 255 / np.log(1 + np.max(image))
log_image = c * (np.log(image + 1))

# menspesifikasi data sehingga float diubah ke int
log_image = np.array(log_image, dtype=np.uint8)

# Display image (logo_DC.jpg)
plt.imshow(image)
plt.show()
plt.imshow(log_image)
plt.show()


#====================ROBERT EDGE============================
import cv2  # mengimport cv2
import numpy as np  # mengimport numpy sebagai np

image = cv2.imread('logo_DC.jpeg', 0)  # mengimport image ('logo_DC.jpeg',0)
image = cv2.resize(image, (800, 800))  # meresize image 800,800

# Roberts edge operator
kernel_Roberts_x = np.array([
    [1, 0],
    [0, -1]
])
kernel_Roberts_y = np.array([
    [0, -1],
    [1, 0]
])
# Sobel edge operator
kernel_Sobel_x = np.array([
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]])
kernel_Sobel_y = np.array([
    [1, 2, 1],
    [0, 0, 0],
    [-1, -2, -1]])
# Prewitt edge operator
kernel_Prewitt_x = np.array([
    [-1, 0, 1],
    [-1, 0, 1],
    [-1, 0, 1]])
kernel_Prewitt_y = np.array([
    [1, 1, 1],
    [0, 0, 0],
    [-1, -1, -1]])


# Kirsch edge detection operator
def kirsch(image):
    m, n = image.shape
    list = []
    kirsch = np.zeros((m, n))
    for i in range(2, m - 1):
        for j in range(2, n - 1):
            d1 = np.square(5 * image[i - 1, j - 1] + 5 * image[i - 1, j] + 5 * image[i - 1, j + 1] -
                           3 * image[i, j - 1] - 3 * image[i, j + 1] - 3 * image[i + 1, j - 1] -
                           3 * image[i + 1, j] - 3 * image[i + 1, j + 1])
            d2 = np.square((-3) * image[i - 1, j - 1] + 5 * image[i - 1, j] + 5 * image[i - 1, j + 1] -
                           3 * image[i, j - 1] + 5 * image[i, j + 1] - 3 * image[i + 1, j - 1] -
                           3 * image[i + 1, j] - 3 * image[i + 1, j + 1])
            d3 = np.square((-3) * image[i - 1, j - 1] - 3 * image[i - 1, j] + 5 * image[i - 1, j + 1] -
                           3 * image[i, j - 1] + 5 * image[i, j + 1] - 3 * image[i + 1, j - 1] -
                           3 * image[i + 1, j] + 5 * image[i + 1, j + 1])
            d4 = np.square((-3) * image[i - 1, j - 1] - 3 * image[i - 1, j] - 3 * image[i - 1, j + 1] -
                           3 * image[i, j - 1] + 5 * image[i, j + 1] - 3 * image[i + 1, j - 1] +
                           5 * image[i + 1, j] + 5 * image[i + 1, j + 1])
            d5 = np.square((-3) * image[i - 1, j - 1] - 3 * image[i - 1, j] - 3 * image[i - 1, j + 1] - 3
                           * image[i, j - 1] - 3 * image[i, j + 1] + 5 * image[i + 1, j - 1] +
                           5 * image[i + 1, j] + 5 * image[i + 1, j + 1])
            d6 = np.square((-3) * image[i - 1, j - 1] - 3 * image[i - 1, j] - 3 * image[i - 1, j + 1] +
                           5 * image[i, j - 1] - 3 * image[i, j + 1] + 5 * image[i + 1, j - 1] +
                           5 * image[i + 1, j] - 3 * image[i + 1, j + 1])
            d7 = np.square(5 * image[i - 1, j - 1] - 3 * image[i - 1, j] - 3 * image[i - 1, j + 1] +
                           5 * image[i, j - 1] - 3 * image[i, j + 1] + 5 * image[i + 1, j - 1] -
                           3 * image[i + 1, j] - 3 * image[i + 1, j + 1])
            d8 = np.square(5 * image[i - 1, j - 1] + 5 * image[i - 1, j] - 3 * image[i - 1, j + 1] +
                           5 * image[i, j - 1] - 3 * image[i, j + 1] - 3 * image[i + 1, j - 1] -
                           3 * image[i + 1, j] - 3 * image[i + 1, j + 1])

            # : Take the maximum value in each direction, the effect is not good, use another method
            list = [d1, d2, d3, d4, d5, d6, d7, d8]
            kirsch[i, j] = int(np.sqrt(max(list)))
            # : Rounding the die length in all directions
            # kirsch[i, j] =int(np.sqrt(d1+d2+d3+d4+d5+d6+d7+d8))
    for i in range(m):
        for j in range(n):
            if kirsch[i, j] > 127:
                kirsch[i, j] = 255
            else:
                kirsch[i, j] = 0
    return kirsch


# Deteksi CannyEdge k adalah ukuran kernel Gaussian, t1, t2 adalah ukuran ambang batas
def Canny(image, k, t1, t2):
    img = cv2.GaussianBlur(image, (k, k), 0)
    canny = cv2.Canny(img, t1, t2)
    return canny


kernel_Laplacian_1 = np.array([
    [0, 1, 0],
    [1, -4, 1],
    [0, 1, 0]])
kernel_Laplacian_2 = np.array([
    [1, 1, 1],
    [1, -8, 1],
    [1, 1, 1]])

# Dua kernel konvolusi tidak memiliki invariansi rotasi

kernel_Laplacian_3 = np.array([
    [2, -1, 2],
    [-1, -4, -1],
    [2, 1, 2]])
kernel_Laplacian_4 = np.array([
    [-1, 2, -1],
    [2, -4, 2],
    [-1, 2, -1]])

# 5 * 5 Kerangka Konvolusi LoG
kernel_LoG = np.array([
    [0, 0, -1, 0, 0],
    [0, -1, -2, -1, 0],
    [-1, -2, 16, -2, -1],
    [0, -1, -2, -1, 0],
    [0, 0, -1, 0, 0]])

# convolution

output_1 = cv2.filter2D(image, -1, kernel_Prewitt_x)
output_2 = cv2.filter2D(image, -1, kernel_Sobel_x)
output_3 = cv2.filter2D(image, -1, kernel_Prewitt_x)
output_4 = cv2.filter2D(image, -1, kernel_Laplacian_1)
output_5 = Canny(image, 3, 50, 150)
output_6 = kirsch(image)
# Show sharpening effect
image = cv2.resize(image, (800, 600))
output_1 = cv2.resize(output_1, (800, 600))
output_2 = cv2.resize(output_2, (800, 600))
output_3 = cv2.resize(output_3, (800, 600))
output_4 = cv2.resize(output_4, (800, 600))
output_5 = cv2.resize(output_5, (800, 600))
output_6 = cv2.resize(output_6, (800, 600))
cv2.imshow('Original Image', image)
cv2.imshow('sharpen_1 Image', output_1)
cv2.imshow('sharpen_2 Image', output_2)
cv2.imshow('sharpen_3 Image', output_3)
cv2.imshow('sharpen_4 Image', output_4)
cv2.imshow('sharpen_5 Image', output_5)
cv2.imshow('sharpen_6 Image', output_6)
#
if cv2.waitKey(0) & 0xFF == 27:
    cv2.destroyAllWindows()

#==================HIGH BOOST================

import cv2  # mengimport package cv2
import matplotlib.pyplot as plt  # mengimport package matplotlib.pyplot sebagai plt


class imageSizeError(Exception):
    def __init__(self):
        self.value = "Image size error"

    def __str__(self):
        return self.value


# Pengurangan matriks

def decreaseArray(image1, image2):
    if image1.shape == image2.shape:
        image = image1.copy()
        for i in range(image1.shape[0] - 1):
            for j in range(image1.shape[1] - 1):
                image[i][j] = image1[i][j] - image2[i][j]
                j = j + 1
            i = i + 1
        return image
    else:
        raise imageSizeError()


# Penambahan matrix
def increaseArray(image1, image2):
    if image1.shape == image2.shape:
        image = image1.copy()
        for i in range(image1.shape[0] - 1):
            for j in range(image1.shape[1] - 1):
                image[i][j] = image1[i][j] + image2[i][j]
                j = j + 1
            i = i + 1
        return image
    else:
        raise imageSizeError()


# Display function

def showImages(images):
    for i in range(len(images)):
        img = images[i]
        title = "(" + str(i + 1) + ")"
        # Row, column, index
        plt.subplot(2, 2, i + 1)
        plt.imshow(img, cmap="gray")
        plt.title(title, fontsize=10)
        plt.xticks([])
        plt.yticks([])
    plt.show()


if __name__ == "__main__":
    image = cv2.imread("image.jpg")
    imageAver3 = cv2.blur(image, (3, 3))
    unsharpMask = decreaseArray(image, imageAver3)
    imageSharp = increaseArray(image, unsharpMask)
    images = [image, imageAver3, unsharpMask, imageSharp]
    showImages(images)

#=======================FREI CHEN===================

